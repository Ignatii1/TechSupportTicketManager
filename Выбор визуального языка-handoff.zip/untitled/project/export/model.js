// Модель данных и правила. Все пороги — явные значения.
export const COLUMNS = ["inbox", "work", "wait", "done"];
export const COLUMN_TITLE = { inbox: "Входящие", work: "В работе", wait: "Ждёт ответа", done: "Готово" };
export const PRIORITY = { low: "Низкий", mid: "Средний", high: "Высокий" };
export const RULES = { overdueDays: 3, overloadLimit: 5, hideDoneDays: 7 };
export const INTRASERVICE_URL = "https://intraservice.corp.local/Task/View/";

/** Распознаёт номер заявки из ссылки Интрасервиса (…/Task/View/702180) или строки "#702180" / "№ 702180". */
export const parseTicketNumber = (s) => { const m = /(?:Task\/View\/|[#№]\s?)(\d{5,7})/i.exec(s || ""); return m ? Number(m[1]) : null; };

/** Возраст в колонке → состояние индикатора. Готово никогда не краснеет. */
export const ageState = (days, col, rules = RULES) => {
  if (col === "done") return "neutral";
  if (days >= rules.overdueDays) return "overdue";
  if (days >= rules.overdueDays - 1) return "warn";
  return "neutral";
};
export const ageLabel = (days) => (days === 0 ? "сегодня" : days + " д");
export const isOverloaded = (count, rules = RULES) => count > rules.overloadLimit;
export const isHiddenDone = (ticket, hideOld, rules = RULES) => hideOld && ticket.col === "done" && ticket.days > rules.hideDoneDays;
