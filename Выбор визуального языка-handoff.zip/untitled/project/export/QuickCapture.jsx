import React, { useEffect, useRef, useState } from "react";
import { PRIORITY, parseTicketNumber } from "./model.js";
import { AppIcon, CheckIcon, Key } from "./icons.jsx";

/** Quick capture 480×160. Глобальный хоткей Win+Shift+Space. Enter — создать во «Входящих», Esc — закрыть,
 *  1/2/3 — приоритет (когда поле пустое или содержит распознанную ссылку). */
export function QuickCapture({ initial = "", resolveTitle, onSubmit, onClose }) {
  const [text, setText] = useState(initial);
  const [prio, setPrio] = useState("mid");
  const ref = useRef(null);
  useEffect(() => { ref.current && ref.current.focus(); }, []);
  const num = parseTicketNumber(text);
  const preview = num ? (resolveTitle && resolveTitle(num)) || "Название подтянется из Интрасервиса" : "";
  const onKey = (e) => {
    if (e.key === "Escape") { e.preventDefault(); onClose(); }
    else if (e.key === "Enter") { e.preventDefault(); if (text.trim()) onSubmit({ text: text.trim(), num, prio }); }
    else if (["1", "2", "3"].includes(e.key) && (!text || num)) { e.preventDefault(); setPrio(["low", "mid", "high"][Number(e.key) - 1]); }
  };
  return (
    <div className="quick" onKeyDown={onKey}>
      <div className="quick-head"><AppIcon /><span>Быстрое добавление</span><span style={{ marginLeft: "auto" }}><Key>Esc</Key></span></div>
      <input ref={ref} value={text} onChange={(e) => setText(e.target.value)} placeholder="Вставьте ссылку из Интрасервиса или введите название" />
      <div className="quick-row">
        {num ? (<><span className="quick-recognized"><CheckIcon /><span className="num">#{num}</span></span><span className="quick-preview">{preview}</span></>)
             : <span className="quick-hint">{text ? "Будет создана заявка с этим названием" : "Ссылка вида …/Task/View/702180 распознаётся автоматически"}</span>}
        <div className="quick-prios">
          {Object.keys(PRIORITY).map((p, i) => <button key={p} className={p + (prio === p ? " on" : "")} onClick={() => setPrio(p)}><kbd>{i + 1}</kbd>{PRIORITY[p]}</button>)}
        </div>
      </div>
      <div className="quick-foot"><Key>Enter</Key><span>во «Входящие»</span><span style={{ marginLeft: "auto" }}>Глобальный хоткей: Win+Shift+Space</span></div>
    </div>
  );
}
