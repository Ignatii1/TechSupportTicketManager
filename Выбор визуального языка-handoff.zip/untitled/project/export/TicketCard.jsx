import React from "react";
import { PRIORITY, INTRASERVICE_URL, ageState, ageLabel } from "./model.js";
import { OpenIcon, NoteIcon } from "./icons.jsx";

/** Карточка заявки. Состояния: selected, dragging, overdue (через ageState), moved (анимация). */
export function TicketCard({ ticket, selected, dragging, moved, onSelect, onDragStart, onDragEnd }) {
  const age = ageState(ticket.days, ticket.col);
  const cls = ["card", selected && "selected", dragging && "dragging", age === "overdue" && "overdue", moved && "moved"].filter(Boolean).join(" ");
  return (
    <div className={cls} tabIndex={0} draggable onClick={onSelect} onDragStart={onDragStart} onDragEnd={onDragEnd}>
      <div className="card-row">
        <span className="card-num">#{ticket.num}</span>
        <span className={"age " + age}>{ageLabel(ticket.days)}</span>
      </div>
      <div className="card-title">{ticket.title}</div>
      <div className="card-row" style={{ height: 20 }}>
        <span className={"chip " + ticket.prio}>{PRIORITY[ticket.prio]}</span>
        <span className="card-notes"><NoteIcon />{ticket.notes.length}</span>
        <a className="card-open" href={INTRASERVICE_URL + ticket.num} target="_blank" rel="noreferrer" title="Открыть в Интрасервисе" onClick={(e) => e.stopPropagation()}><OpenIcon /></a>
      </div>
    </div>
  );
}
