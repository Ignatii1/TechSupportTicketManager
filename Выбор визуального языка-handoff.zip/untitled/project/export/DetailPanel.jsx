import React, { useState } from "react";
import { PRIORITY, INTRASERVICE_URL, ageState } from "./model.js";
import { OpenIcon, ChevronIcon, CloseIcon, Key } from "./icons.jsx";

const fmtDate = (d) => d.toLocaleDateString("ru-RU", { day: "2-digit", month: "2-digit", year: "numeric" });
const fmtTime = (d) => d.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
const plural = (n, a, b, c) => { const m = n % 10, h = n % 100; return n + " " + (h > 10 && h < 20 ? c : m === 1 ? a : m > 1 && m < 5 ? b : c); };

/** Панель деталей 380px. open — ширина 0→380 за 200ms; overlay — position:absolute + scrim при ширине окна < 1100. */
export function DetailPanel({ ticket, open, overlay, onClose, onStatusChange, onPriorityChange, onAddNote }) {
  const [text, setText] = useState("");
  const [lastNote, setLastNote] = useState(null);
  const submit = () => { const v = text.trim(); if (!v) return; const at = new Date(); onAddNote({ at, text: v }); setLastNote(at.getTime()); setText(""); };
  const age = ticket ? ageState(ticket.days, ticket.col) : "neutral";
  return (
    <>
      {overlay && open && <div className="scrim" onClick={onClose} />}
      <div className={["panel-host", open && "open", overlay && "overlay"].filter(Boolean).join(" ")}>
        {ticket && (
          <div className="panel">
            <div className="panel-header">
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="panel-title">{ticket.title}</div>
                <a className="panel-link" href={INTRASERVICE_URL + ticket.num} target="_blank" rel="noreferrer"><span style={{ fontFamily: "var(--font-mono)" }}>#{ticket.num}</span> · Открыть в Интрасервисе <OpenIcon size={12} /></a>
              </div>
              <button className="btn-icon" title="Закрыть (Esc)" onClick={onClose}><CloseIcon /></button>
            </div>
            <div className="panel-desc">{ticket.desc}</div>
            <div className="panel-meta">
              <span className="label">Статус</span>
              <div className="combobox sm" style={{ justifySelf: "start" }}>
                <select value={ticket.col} onChange={(e) => onStatusChange(e.target.value)}>
                  <option value="inbox">Входящие</option><option value="work">В работе</option><option value="wait">Ждёт ответа</option><option value="done">Готово</option>
                </select>
                <span className="chevron" style={{ top: 8, right: 8 }}><ChevronIcon /></span>
              </div>
              <span className="label">Приоритет</span>
              <div className="prio-seg">{Object.keys(PRIORITY).map((p) => <button key={p} className={p + (ticket.prio === p ? " on" : "")} onClick={() => onPriorityChange(p)}>{PRIORITY[p]}</button>)}</div>
              <span className="label">Добавлена</span><span>{fmtDate(ticket.added)}</span>
              <span className="label">В колонке</span>
              <span style={{ color: age === "overdue" ? "var(--critical-fg)" : age === "warn" ? "var(--caution-fg)" : "inherit" }}>{ticket.days === 0 ? "с сегодня" : plural(ticket.days, "день", "дня", "дней") + (age === "overdue" ? " — просрочена" : "")}</span>
            </div>
            <div className="panel-divider" />
            <div className="notes-header"><span>Заметки</span><span className="count">{ticket.notes.length}</span></div>
            <div className="notes">
              {[...ticket.notes].reverse().map((n, i) => (
                <div key={i} className={"note" + (n.at.getTime() === lastNote ? " new" : "")}>
                  <span className="note-time">{fmtDate(n.at).slice(0, 5)} {fmtTime(n.at)}</span>
                  <span>{n.text}</span>
                </div>
              ))}
            </div>
            <div className="note-input">
              <div className="textbox">
                <input value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); submit(); } }} placeholder="Что сделано — Enter добавит запись" style={{ paddingLeft: 10 }} />
                <Key>Enter</Key>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
