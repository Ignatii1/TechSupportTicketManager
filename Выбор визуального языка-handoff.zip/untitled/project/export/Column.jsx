import React, { useState } from "react";
import { COLUMN_TITLE, RULES, isOverloaded } from "./model.js";
import { TicketCard } from "./TicketCard.jsx";
import { WarnIcon, Key } from "./icons.jsx";

export function Column({ col, tickets, selectedId, dragId, movedId, hideOld, showInboxEmpty, onSelect, onDragStart, onDragEnd, onDrop }) {
  const [over, setOver] = useState(false);
  const overload = col === "work" && isOverloaded(tickets.length);
  const hint = col === "work" ? "лимит " + RULES.overloadLimit : col === "done" && hideOld ? "скрыты старше " + RULES.hideDoneDays + " д" : "";
  return (
    <div className={"column" + (over && dragId ? " drop-target" : "")}
      onDragOver={(e) => { e.preventDefault(); e.dataTransfer.dropEffect = "move"; setOver(true); }}
      onDragLeave={(e) => { if (!e.currentTarget.contains(e.relatedTarget)) setOver(false); }}
      onDrop={(e) => { e.preventDefault(); setOver(false); onDrop(Number(e.dataTransfer.getData("text/plain")) || dragId, col); }}>
      <div className="column-header">
        <span className="column-title">{COLUMN_TITLE[col]}</span>
        <span className={"column-count" + (overload ? " overload" : "")}>{tickets.length}</span>
        {overload && <span className="column-overload"><WarnIcon />перегруз</span>}
        <span className="column-hint">{hint}</span>
      </div>
      {showInboxEmpty && <div className="column-empty">Входящих нет — всё в работе.<br />Новая заявка: <Key>N</Key></div>}
      {tickets.map((t) => (
        <TicketCard key={t.id} ticket={t} selected={t.id === selectedId} dragging={t.id === dragId} moved={t.id === movedId}
          onSelect={() => onSelect(t.id)} onDragStart={(e) => { e.dataTransfer.setData("text/plain", String(t.id)); onDragStart(t.id); }} onDragEnd={onDragEnd} />
      ))}
    </div>
  );
}
