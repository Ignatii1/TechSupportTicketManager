import React, { useEffect, useRef, useState } from "react";
import "./styles.css";
import { COLUMNS, RULES, isHiddenDone } from "./model.js";
import { TitleBar } from "./TitleBar.jsx";
import { Column } from "./Column.jsx";
import { DetailPanel } from "./DetailPanel.jsx";
import { QuickCapture } from "./QuickCapture.jsx";
import { AppIcon, Key } from "./icons.jsx";

/** Корневое окно. theme: "light" | "dark". width < 1100 → панель деталей в режиме overlay. */
export function App({ theme = "light", width = 1280, initialTickets = [] }) {
  const [tickets, setTickets] = useState(initialTickets);
  const [selectedId, setSelectedId] = useState(null);
  const [panelOpen, setPanelOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [prioFilter, setPrioFilter] = useState("all");
  const [hideOld, setHideOld] = useState(true);
  const [dragId, setDragId] = useState(null);
  const [movedId, setMovedId] = useState(null);
  const [quick, setQuick] = useState(false);
  const searchRef = useRef(null);
  const overlay = width < 1100;

  const visible = tickets
    .filter((t) => { const q = search.trim().toLowerCase(); return !q || t.title.toLowerCase().includes(q) || String(t.num).includes(q); })
    .filter((t) => prioFilter === "all" || t.prio === prioFilter)
    .filter((t) => !isHiddenDone(t, hideOld));

  const flashMoved = (id) => { setMovedId(id); setTimeout(() => setMovedId(null), 250); };
  const moveTo = (id, col) => { setTickets((ts) => ts.map((t) => (t.id === id && t.col !== col ? { ...t, col, days: 0 } : t))); flashMoved(id); };
  const moveBy = (id, dir) => { const t = tickets.find((x) => x.id === id); if (!t) return; const i = COLUMNS.indexOf(t.col) + dir; if (i >= 0 && i < 4) moveTo(id, COLUMNS[i]); };
  const update = (id, patch) => setTickets((ts) => ts.map((t) => (t.id === id ? { ...t, ...patch } : t)));

  useEffect(() => {
    const onKey = (e) => {
      if (quick) return; // QuickCapture обрабатывает свои клавиши сам
      const tag = e.target.tagName, inField = tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT";
      if (e.key === "Escape") { inField ? e.target.blur() : setPanelOpen(false); return; }
      if (inField) return;
      const k = e.key.toLowerCase();
      if (k === "n" || k === "т") { e.preventDefault(); setQuick(true); }
      else if (e.key === "/") { e.preventDefault(); searchRef.current?.focus(); }
      else if (e.key === "ArrowLeft" && selectedId) { e.preventDefault(); moveBy(selectedId, -1); }
      else if (e.key === "ArrowRight" && selectedId) { e.preventDefault(); moveBy(selectedId, 1); }
      else if (e.key === "Enter" && selectedId) { e.preventDefault(); setPanelOpen((o) => !o); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const selected = tickets.find((t) => t.id === selectedId) || null;
  return (
    <div data-theme={theme} className="window" style={{ width }}>
      <TitleBar searchRef={searchRef} search={search} onSearch={setSearch} prioFilter={prioFilter} onPrioFilter={setPrioFilter} hideOld={hideOld} onToggleHideOld={() => setHideOld((v) => !v)} onNew={() => setQuick(true)} />
      <div className="window-body">
        <div className="board">
          {visible.length === 0 && (
            <div className="board-empty">
              <AppIcon size={40} strokeWidth={0.9} />
              <h2>Заявок пока нет</h2>
              <p>Добавьте первую: нажмите <Key>N</Key> или вставьте ссылку из Интрасервиса через быстрое добавление — <Key>Win+Shift+Space</Key> из любого окна.</p>
              <button className="btn-accent" style={{ marginTop: 8 }} onClick={() => setQuick(true)}>Добавить заявку</button>
            </div>
          )}
          <div className="board-grid" style={{ opacity: visible.length === 0 ? 0.35 : 1 }}>
            {COLUMNS.map((col) => (
              <Column key={col} col={col} tickets={visible.filter((t) => t.col === col)} selectedId={selectedId} dragId={dragId} movedId={movedId} hideOld={hideOld}
                showInboxEmpty={col === "inbox" && visible.length > 0 && !visible.some((t) => t.col === "inbox")}
                onSelect={(id) => { setSelectedId(id); setPanelOpen(true); }} onDragStart={(id) => { setDragId(id); setSelectedId(id); }} onDragEnd={() => setDragId(null)} onDrop={(id, c) => { moveTo(id, c); setDragId(null); }} />
            ))}
          </div>
        </div>
        <DetailPanel ticket={selected} open={panelOpen && !!selected} overlay={overlay} onClose={() => setPanelOpen(false)}
          onStatusChange={(col) => moveTo(selectedId, col)} onPriorityChange={(prio) => update(selectedId, { prio })}
          onAddNote={(n) => update(selectedId, { notes: [...selected.notes, n] })} />
      </div>
      {quick && (
        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", zIndex: 20 }} onClick={() => setQuick(false)}>
          <div onClick={(e) => e.stopPropagation()}>
            <QuickCapture onClose={() => setQuick(false)} onSubmit={({ text, num, prio }) => {
              const id = num || Date.now();
              setTickets((ts) => [{ id, num: id, title: num ? "Заявка #" + num : text, prio, col: "inbox", days: 0, added: new Date(), desc: "", notes: [] }, ...ts]);
              setSelectedId(id); flashMoved(id); setQuick(false);
            }} />
          </div>
        </div>
      )}
    </div>
  );
}
