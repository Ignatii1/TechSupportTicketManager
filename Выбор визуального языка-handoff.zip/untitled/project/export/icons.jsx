import React from "react";
const P = { fill: "none", stroke: "currentColor", strokeLinecap: "round", strokeLinejoin: "round" };
export const AppIcon = ({ size = 16, strokeWidth = 1.25 }) => (
  <svg width={size} height={size} viewBox="0 0 16 16" {...P} strokeWidth={strokeWidth}><rect x="2" y="2.5" width="12" height="11" rx="2"/><path d="M5 6h6M5 8.5h4"/><path d="M9.5 11.5l1.2 1.2 2.3-2.4"/></svg>);
export const TrayIcon = ({ badge, warn }) => (
  <span style={{ position: "relative", display: "inline-flex" }}>
    <svg width="16" height="16" viewBox="0 0 16 16" {...P} strokeWidth="1.25"><rect x="2" y="2.5" width="12" height="11" rx="2"/><path d="M5 6h6M5 8.5h4"/></svg>
    {badge ? <span style={{ position: "absolute", right: -5, top: -5, minWidth: 12, height: 12, padding: "0 3px", borderRadius: 6, background: "var(--accent)", color: "var(--on-accent)", font: "600 9px/12px var(--font-ui)", textAlign: "center" }}>{badge}</span> : null}
    {warn ? <span style={{ position: "absolute", right: -2, top: -2, width: 7, height: 7, borderRadius: 4, background: "var(--caution-fg)" }}/> : null}
  </span>);
export const SearchIcon = () => <svg width="16" height="16" viewBox="0 0 16 16" {...P} strokeWidth="1.25"><circle cx="7" cy="7" r="4.5"/><path d="M10.5 10.5L14 14"/></svg>;
export const ChevronIcon = () => <svg width="12" height="12" viewBox="0 0 12 12" {...P} strokeWidth="1.25"><path d="M2.5 4.5L6 8l3.5-3.5"/></svg>;
export const AddIcon = () => <svg width="16" height="16" viewBox="0 0 16 16" {...P} strokeWidth="1.5"><path d="M8 3v10M3 8h10"/></svg>;
export const OpenIcon = ({ size = 14 }) => <svg width={size} height={size} viewBox="0 0 16 16" {...P} strokeWidth="1.25"><path d="M7 3H3.5v9.5H13V9"/><path d="M9 3h4v4M13 3L7.5 8.5"/></svg>;
export const NoteIcon = () => <svg width="14" height="14" viewBox="0 0 16 16" {...P} strokeWidth="1.25"><path d="M3 3.5h10v7H7l-3 2.5v-2.5H3z"/></svg>;
export const WarnIcon = () => <svg width="12" height="12" viewBox="0 0 12 12" {...P} strokeWidth="1.2"><path d="M6 1.5l5 9H1z"/><path d="M6 5v2.5M6 9v.01"/></svg>;
export const CheckIcon = () => <svg width="12" height="12" viewBox="0 0 12 12" {...P} strokeWidth="1.4"><path d="M2 6.5l2.5 2.5L10 3.5"/></svg>;
export const CloseIcon = () => <svg width="12" height="12" viewBox="0 0 12 12" {...P} strokeWidth="1.2"><path d="M1.5 1.5l9 9M10.5 1.5l-9 9"/></svg>;
export const Key = ({ children }) => <kbd className="key">{children}</kbd>;
