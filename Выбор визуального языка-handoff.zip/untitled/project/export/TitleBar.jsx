import React from "react";
import { AppIcon, SearchIcon, ChevronIcon, AddIcon, Key } from "./icons.jsx";

/** Title bar 48px с toolbar внутри. Кнопки окна 46×48 (стандарт Win11). */
export function TitleBar({ searchRef, search, onSearch, prioFilter, onPrioFilter, hideOld, onToggleHideOld, onNew }) {
  return (
    <div className="titlebar">
      <AppIcon />
      <span className="app-title">Заявки</span>
      <div className="textbox search">
        <span className="lead"><SearchIcon /></span>
        <input ref={searchRef} value={search} onChange={(e) => onSearch(e.target.value)} placeholder="Поиск по номеру или названию" />
        <Key>/</Key>
      </div>
      <div className="combobox">
        <select value={prioFilter} onChange={(e) => onPrioFilter(e.target.value)}>
          <option value="all">Все приоритеты</option><option value="high">Высокий</option><option value="mid">Средний</option><option value="low">Низкий</option>
        </select>
        <span className="chevron"><ChevronIcon /></span>
      </div>
      <button className="toggle" role="switch" aria-checked={hideOld} onClick={onToggleHideOld}>
        <span className="track"><span className="knob" /></span>
        <span>Скрыть готовые старше 7 дней</span>
      </button>
      <button className="btn-accent" onClick={onNew}><AddIcon /><span>Заявка</span><Key>N</Key></button>
      <div className="caption-buttons">
        <span className="caption-button"><svg width="10" height="10" viewBox="0 0 10 10" stroke="currentColor" strokeWidth="1"><path d="M0 5h10" /></svg></span>
        <span className="caption-button"><svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1"><rect x=".5" y=".5" width="9" height="9" rx="1.5" /></svg></span>
        <span className="caption-button close"><svg width="10" height="10" viewBox="0 0 10 10" stroke="currentColor" strokeWidth="1"><path d="M0 0l10 10M10 0L0 10" /></svg></span>
      </div>
    </div>
  );
}
